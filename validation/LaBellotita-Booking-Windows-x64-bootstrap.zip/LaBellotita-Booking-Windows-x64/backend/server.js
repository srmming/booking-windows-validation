const mongoose = require('mongoose');
const fs = require('node:fs');
const path = require('node:path');
if (process.env.APP_MODE !== 'windows-lan') require('dotenv').config();
const { deploymentConfig, createApp } = require('./app');

async function start() {
  const config = deploymentConfig();
  const frontendReady = fs.existsSync(path.resolve(__dirname, '../frontend/build/index.html'));
  if (config.production && !frontendReady) throw new Error('Build the frontend before starting production.');
  if (!config.demo) {
    await mongoose.connect(config.mongoUri, { serverSelectionTimeoutMS: 10000 });
    console.log('MongoDB connected');
  }
  const app = createApp(config, { isReady: () => frontendReady && (config.demo || mongoose.connection.readyState === 1) });
  if (config.lan) {
    // Models register when business routes mount. Do not announce readiness
    // while their initial background index builds can still reject shutdown.
    await Promise.all(Object.values(mongoose.models).map(model => model.init()));
    console.log('Local database indexes ready');
  }
  const port = Number(process.env.PORT) || 5001;
  const server = app.listen(port, '0.0.0.0', () => console.log(`Server running on port ${port} (${config.demo ? 'read-only demo' : 'business'})`));
  server.on('error', () => { console.error('Application port is unavailable.'); mongoose.disconnect().finally(() => process.exit(1)); });
  // IPC lets the packaged supervisor drain HTTP before cleanly stopping MongoDB on Windows.
  const stop = () => {
    console.log('HTTP stop requested');
    server.close(async () => {
      console.log('HTTP requests drained');
      await mongoose.disconnect();
      console.log('Application Mongo connection closed');
      process.exit(0);
    });
    server.closeIdleConnections();
  };
  process.on('message', message => { if (message === 'stop') stop(); });
  if (process.send) process.on('disconnect', stop);
  for (const signal of ['SIGTERM', 'SIGINT']) {
    process.once(signal, () => {
      const timeout = setTimeout(() => process.exit(1), 10000);
      timeout.unref();
      server.close(async () => {
        await mongoose.disconnect();
        clearTimeout(timeout);
        process.exit(0);
      });
    });
  }
}

start().catch(() => {
  // Do not print connection errors, which can contain database credentials.
  console.error('Startup failed. Check the frontend build and required deployment configuration.');
  process.exitCode = 1;
});
