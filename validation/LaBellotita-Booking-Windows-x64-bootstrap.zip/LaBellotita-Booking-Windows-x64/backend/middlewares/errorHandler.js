// Simple error handler - no fancy bullshit
module.exports = (err, req, res, next) => {
  console.error('Error:', process.env.NODE_ENV === 'production' ? 'Request failed' : err.message);
  if (process.env.NODE_ENV === 'development') {
    console.error(err.stack);
  }
  
  // Keep a simple, consistent error shape to avoid surprising clients
  const status = err.status || 500;
  const message = process.env.NODE_ENV === 'production' && status >= 500
    ? 'Internal Server Error'
    : err.message || 'Internal Server Error';
  res.status(status).json({ error: message });
};
