const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const cors = require('cors');
const net = require('node:net');

function privateIPv4(value) {
  const ip = (value || '').replace(/^::ffff:/, '');
  if (!net.isIPv4(ip)) return false;
  const [a, b] = ip.split('.').map(Number);
  return a === 127 || a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

function lanBoundary(req, res, next) {
  let host;
  try { host = new URL(`http://${req.get('host')}`).hostname; } catch (_) {}
  if (!privateIPv4(req.socket.remoteAddress) || !(host === 'localhost' || privateIPv4(host))) {
    return res.status(403).json({ error: 'Windows LAN mode accepts private IPv4 networks only.' });
  }
  if (req.get('sec-fetch-site') === 'cross-site') return res.sendStatus(403);
  next();
}

function deploymentConfig(env = process.env) {
  const demo = env.DEMO_MODE === 'true';
  const production = env.NODE_ENV === 'production';
  const lan = env.APP_MODE === 'windows-lan';
  if (env.APP_MODE && !lan) throw new Error('Unknown APP_MODE.');
  if (lan) {
    if (!production || demo || env.APP_USERNAME || env.APP_PASSWORD) throw new Error('Windows LAN mode requires production assets, business mode and no cloud credentials.');
    if (!/^mongodb:\/\/127\.0\.0\.1:[1-9]\d{0,4}\/labellotita_booking_local$/.test(env.MONGODB_URI || '') || Number(new URL(env.MONGODB_URI).port) > 65535) {
      throw new Error('Windows LAN mode requires its explicit dedicated loopback database.');
    }
  }
  if (demo && env.MONGODB_URI) {
    throw new Error('Demo mode must not have MONGODB_URI configured.');
  }
  if (production && !demo && !lan) {
    if (!env.APP_USERNAME || env.APP_USERNAME.includes(':') || !env.APP_PASSWORD || env.APP_PASSWORD.length < 16) {
      throw new Error('Production requires APP_USERNAME and APP_PASSWORD (at least 16 characters).');
    }
    if (!env.MONGODB_URI) {
      throw new Error('Production requires an explicitly approved MONGODB_URI.');
    }
  }
  return {
    demo,
    production,
    lan,
    username: env.APP_USERNAME,
    password: env.APP_PASSWORD,
    mongoUri: env.MONGODB_URI || 'mongodb://localhost:27017/order-system'
  };
}

function basicAuth(username, password) {
  const expected = crypto.createHash('sha256').update(`${username}:${password}`).digest();
  return (req, res, next) => {
    const match = /^Basic ([A-Za-z0-9+/]+={0,2})$/i.exec(req.get('authorization') || '');
    const supplied = match ? Buffer.from(match[1], 'base64').toString('utf8') : '';
    const digest = crypto.createHash('sha256').update(supplied).digest();
    if (match && crypto.timingSafeEqual(expected, digest)) return next();
    res.set('WWW-Authenticate', 'Basic realm="La Bellotita", charset="UTF-8"');
    res.set('Cache-Control', 'no-store');
    return res.status(401).send('Authentication required');
  };
}

function demoRoutes() {
  const router = express.Router();
  router.use((req, res, next) => {
    if (req.method === 'GET' || req.method === 'HEAD') return next();
    return res.status(403).json({ error: '只读演示：无法保存业务数据。' });
  });
  router.get(['/orders/stats', '/stock-orders/stats'], (req, res) => {
    res.json({ totalOrders: 0, pendingOrders: 0, shippingOrders: 0, completedOrders: 0, totalRevenue: 0, totalAmount: 0, upcomingShipments: [] });
  });
  router.get('/products/combo-targets/summary', (req, res) => {
    res.json({ year: Number(req.query.year) || new Date().getFullYear(), combos: [], totals: { target: 0, shipped: 0, reserved: 0, ordered: 0, remaining: 0, shortage: 0, combosCount: 0, baseProductsCount: 0 } });
  });
  router.get(['/customers', '/products', '/orders', '/stock-orders', '/shipments', '/stock-shipments', '/production/plan'], (req, res) => res.json([]));
  router.use((req, res) => res.status(404).json({ error: '演示模式没有此记录。' }));
  return router;
}

function createApp(config, options = {}) {
  const app = express();
  app.disable('x-powered-by');
  if (config.lan) app.use(lanBoundary);
  app.use((req, res, next) => {
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('X-Frame-Options', 'DENY');
    res.set('Referrer-Policy', 'same-origin');
    if (!config.demo) res.set('Cache-Control', 'no-store');
    next();
  });

  app.get('/health', (req, res) => {
    const ready = options.isReady ? options.isReady() : true;
    res.status(ready ? 200 : 503).json({ status: ready ? 'OK' : 'NOT_READY', mode: config.demo ? 'demo' : 'business' });
  });

  if (!config.demo && config.username && config.password) {
    app.use(basicAuth(config.username, config.password));
  }
  if (config.production && !config.demo) {
    app.use((req, res, next) => {
      if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || !req.get('origin')) return next();
      try {
        if (new URL(req.get('origin')).host === req.get('host')) return next();
      } catch (_) {}
      return res.status(403).json({ error: 'Cross-origin writes are forbidden' });
    });
  }
  if (!config.production) app.use(cors({ origin: 'http://localhost:3000' }));
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  app.get('/api/config', (req, res) => res.json({ readOnly: config.demo, demo: config.demo }));

  if (config.demo) {
    app.use('/api', demoRoutes());
  } else {
    for (const [name, file] of Object.entries({ customers: 'customers', products: 'products', orders: 'orders', shipments: 'shipments', 'stock-orders': 'stockOrders', 'stock-shipments': 'stockShipments', production: 'production' })) {
      app.use(`/api/${name}`, require(`./routes/${file}`));
    }
  }
  app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found' }));

  const buildDir = options.buildDir || path.resolve(__dirname, '../frontend/build');
  app.use(express.static(buildDir, { index: false, dotfiles: 'deny' }));
  app.get('*', (req, res) => {
    if (!req.accepts('html') || path.extname(req.path)) return res.sendStatus(404);
    const index = path.join(buildDir, 'index.html');
    if (!fs.existsSync(index)) return res.status(503).send('Frontend build is unavailable');
    res.set('Cache-Control', 'no-store');
    return res.sendFile(index);
  });
  app.use(require('./middlewares/errorHandler'));
  return app;
}

module.exports = { deploymentConfig, createApp, privateIPv4 };
