'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function atomicJSON(file, value) {
  const tmp = `${file}.${crypto.randomUUID()}.tmp`;
  const fd = fs.openSync(tmp, 'wx');
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  try { fs.renameSync(tmp, file); } catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
}
function readJSON(file) {
  if (fs.statSync(file).size > 16 * 1024 * 1024) throw new Error('Metadata too large.');
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}
function acquireLock(root) {
  fs.mkdirSync(root, { recursive: true });
  const file = path.join(root, 'operation.lock');
  const instance = crypto.randomUUID();
  // Every claimant, including stale-lock recovery, is serialized by atomic mkdir.
  // An abandoned claim gate needs support inspection; never reclaim this gate by another racy check/unlink.
  const gate = path.join(root, 'operation-claim');
  try { fs.mkdirSync(gate); } catch (error) {
    if (error.code === 'EEXIST') throw new Error('Another operation is acquiring the lock. Retry shortly; if this persists, ask support to inspect operation-claim.');
    throw error;
  }
  try {
  fs.writeFileSync(path.join(gate, 'owner.json'), JSON.stringify({ pid: process.pid, instance }));
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = fs.openSync(file, 'wx');
      try { fs.writeFileSync(fd, JSON.stringify({ pid: process.pid, instance })); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      return { instance, release() { if (readJSON(file).instance === instance) fs.unlinkSync(file); } };
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      let owner;
      try { owner = readJSON(file); } catch (_) { throw new Error('Unreadable operation lock. Ask support to inspect it; no data was changed.'); }
      if (!Number.isSafeInteger(owner.pid) || owner.pid <= 0) throw new Error('Invalid operation lock.');
      try { process.kill(owner.pid, 0); } catch (e) {
        if (e.code === 'ESRCH') { fs.unlinkSync(file); continue; }
      }
      throw new Error('The system is already running or another operation is in progress. Stop it first.');
    }
  }
  throw new Error('Cannot acquire operation lock.');
  } finally { fs.rmSync(gate, { recursive: true }); }
}
function generation(root) {
  const pointer = path.join(root, 'active.json');
  if (!fs.existsSync(pointer)) {
    const name = `data-${crypto.randomUUID()}`;
    fs.mkdirSync(path.join(root, 'generations', name), { recursive: true });
    atomicJSON(pointer, { generation: name });
  }
  const { generation: name } = readJSON(pointer);
  if (!/^data-[a-f0-9-]{36}$/.test(name)) throw new Error('Invalid data generation.');
  const dir = path.join(root, 'generations', name);
  if (!fs.existsSync(dir) || !fs.lstatSync(dir).isDirectory() || fs.lstatSync(dir).isSymbolicLink()) throw new Error('Data directory missing or unsafe.');
  return dir;
}
function filesIn(dir, prefix = '') {
  const result = [];
  for (const entry of fs.readdirSync(dir).sort()) {
    const rel = prefix ? `${prefix}/${entry}` : entry;
    const full = path.join(dir, entry);
    const stat = fs.lstatSync(full);
    if (stat.isSymbolicLink()) throw new Error('Links are forbidden in data snapshots.');
    if (stat.isDirectory()) result.push(...filesIn(full, rel));
    else if (stat.isFile()) result.push({ path: rel, size: stat.size });
    else throw new Error('Unsupported snapshot file.');
  }
  return result;
}
async function digest(file) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
async function inventory(dir) {
  const files = filesIn(dir);
  for (const file of files) file.sha256 = await digest(path.join(dir, file.path));
  return files;
}
async function validateSnapshot(dir, version) {
  if (fs.lstatSync(dir).isSymbolicLink()) throw new Error('Snapshot must not be a link.');
  for (const name of ['manifest.json', 'db']) if (fs.lstatSync(path.join(dir, name)).isSymbolicLink()) throw new Error('Links are forbidden in data snapshots.');
  const manifest = readJSON(path.join(dir, 'manifest.json'));
  if (manifest.format !== 'booking-cold-v1' || manifest.mongoVersion !== version || !Array.isArray(manifest.files) || !Array.isArray(manifest.collections)) throw new Error('Unsupported backup or MongoDB version.');
  if (!manifest.files.length || !manifest.files.some(f => f.path === 'WiredTiger')) throw new Error('Backup has no database.');
  const names = new Set();
  for (const f of manifest.files) {
    if (!f || typeof f.path !== 'string' || !/^[A-Za-z0-9_.\/-]+$/.test(f.path) || f.path.split('/').some(s => !s || s === '.' || s === '..') || f.path.includes(':') || path.isAbsolute(f.path) || names.has(f.path) || !Number.isSafeInteger(f.size) || f.size < 0 || !/^[a-f0-9]{64}$/.test(f.sha256)) throw new Error('Unsafe backup manifest.');
    names.add(f.path);
  }
  for (const c of manifest.collections) {
    if (!c || typeof c.name !== 'string' || !Number.isSafeInteger(c.count) || c.count < 0) throw new Error('Invalid backup collection counts.');
  }
  const actual = await inventory(path.join(dir, 'db'));
  const expected = [...manifest.files].sort((a, b) => a.path.localeCompare(b.path));
  actual.sort((a, b) => a.path.localeCompare(b.path));
  if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error('Backup files are missing, modified or unexpected. Original data is unchanged.');
  return manifest;
}
module.exports = { atomicJSON, readJSON, acquireLock, generation, inventory, validateSnapshot };
