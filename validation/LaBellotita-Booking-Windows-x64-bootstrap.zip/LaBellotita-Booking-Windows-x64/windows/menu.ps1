﻿param(
  [ValidateSet('install','start','stop','backup','restore','addresses')][string]$Action = 'start',
  [switch]$NoGui
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$Root = Join-Path $env:LOCALAPPDATA 'LaBellotitaBooking'
$App = Join-Path $Root 'app'
$Spec = Get-Content (Join-Path $PSScriptRoot 'runtime.json') -Raw | ConvertFrom-Json
$Node = Join-Path $Root "runtime\$($Spec.node.directory)\node.exe"
$Controller = Join-Path $App 'windows\controller.cjs'
function Tell([string]$Text) {
  if ($NoGui) { Write-Output $Text } else { [void][System.Windows.Forms.MessageBox]::Show($Text, 'La Bellotita Booking') }
}
function Confirm([string]$Text) {
  if ($NoGui) { throw 'Interactive confirmation required.' }
  return [System.Windows.Forms.MessageBox]::Show($Text, 'La Bellotita Booking', 'YesNo', 'Warning') -eq 'Yes'
}
function Download-Runtime($Item) {
  $Target = Join-Path $Root "runtime\$($Item.directory)"
  $Exe = if ($Item -eq $Spec.node) { Join-Path $Target 'node.exe' } else { Join-Path $Target 'bin\mongod.exe' }
  if (Test-Path $Exe) { return }
  if (Test-Path $Target) { throw 'Incomplete runtime directory exists. Ask support to inspect it.' }
  $Work = Join-Path $Root ('download-' + [guid]::NewGuid().ToString())
  [void](New-Item $Work -ItemType Directory)
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Write-Host ("Downloading official runtime " + $Item.directory)
    Invoke-WebRequest -UseBasicParsing -Uri $Item.url -OutFile (Join-Path $Work 'runtime.zip') -TimeoutSec 600
    $Hash = (Get-FileHash (Join-Path $Work 'runtime.zip') -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Hash -ne $Item.sha256) { throw 'Official download checksum mismatch. Installation cancelled.' }
    Write-Host ("Download checksum verified: " + $Item.directory)
    Expand-Archive (Join-Path $Work 'runtime.zip') (Join-Path $Work 'expanded')
    $Directory = Join-Path $Work "expanded\$($Item.directory)"
    if (!(Test-Path $Directory)) { throw 'Unexpected runtime archive layout.' }
    [void](New-Item (Join-Path $Root 'runtime') -ItemType Directory -Force)
    Move-Item $Directory $Target
    Write-Host ("Runtime extracted: " + $Item.directory)
  } finally { Remove-Item $Work -Recurse -Force -ErrorAction SilentlyContinue }
}
function Invoke-Controller([string[]]$Arguments) {
  if (!(Test-Path $Node) -or !(Test-Path $Controller)) { throw 'Run Install.cmd first. Keep data in the same Windows account.' }
  $Result = & $Node $Controller @Arguments 2>&1
  if ($LASTEXITCODE -ne 0) { throw ($Result -join "`n") }
  return ($Result -join "`n")
}
try {
  if ($Action -eq 'install') {
    if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64' -or ![Environment]::Is64BitProcess) { throw 'Windows x64 is required. ARM64 is not supported by this package.' }
    $OS = Get-CimInstance Win32_OperatingSystem
    if ($OS.ProductType -eq 1 -and [int]$OS.BuildNumber -lt 22000) { throw 'Windows 11 is required.' }
    if (!$NoGui -and !(Confirm "First installation downloads Node.js and MongoDB Community from official websites. Internet and sufficient disk space are required. MongoDB uses SSPL; licenses remain in its runtime folder. LAN users can read and change all business data without a password. Continue?")) { return }
    $Source = Split-Path $PSScriptRoot -Parent
    $Manifest = Get-Content (Join-Path $Source 'PACKAGE_MANIFEST.json') -Raw | ConvertFrom-Json
    foreach ($File in $Manifest.files) {
      if ($File.path -match '(^/|\\|:|(^|/)\.\.(/|$))') { throw 'Unsafe package manifest.' }
      $Full = Join-Path $Source $File.path
      if (!(Test-Path $Full -PathType Leaf) -or (Get-FileHash $Full -Algorithm SHA256).Hash.ToLowerInvariant() -ne $File.sha256) { throw 'Package verification failed. Extract a fresh package.' }
    }
    Write-Host 'Application package checksum verification completed.'
    [void](New-Item $Root -ItemType Directory -Force)
    [void](New-Item (Join-Path $Root 'logs') -ItemType Directory -Force)
    if (Test-Path (Join-Path $Root 'operation.lock')) { throw 'Stop the system before running installation.' }
    if (Test-Path $App) {
      $Installed = Get-Content (Join-Path $App 'PACKAGE_MANIFEST.json') -Raw
      $Incoming = Get-Content (Join-Path $Source 'PACKAGE_MANIFEST.json') -Raw
      if ($Installed -ne $Incoming) { throw 'An existing application is installed. This installer does not overwrite upgrades or data. Ask support to perform a backed-up upgrade.' }
    } else {
      $Stage = Join-Path $Root ('app-install-' + [guid]::NewGuid().ToString())
      [void](New-Item $Stage -ItemType Directory)
      foreach ($Item in @('backend','frontend','windows','README.txt','THIRD_PARTY_NOTICES.md','PACKAGE_MANIFEST.json')) { Copy-Item (Join-Path $Source $Item) $Stage -Recurse }
      Move-Item $Stage $App
    }
    Download-Runtime $Spec.node
    Download-Runtime $Spec.mongo
    $NodeVersion = & $Node --version
    if ($LASTEXITCODE -ne 0 -or $NodeVersion -ne ('v' + $Spec.node.version)) { throw 'Node runtime validation failed.' }
    $Mongo = Join-Path $Root "runtime\$($Spec.mongo.directory)\bin\mongod.exe"
    $MongoVersion = & $Mongo --version 2>&1
    if ($LASTEXITCODE -ne 0 -or ($MongoVersion -join "`n") -notmatch [regex]::Escape('v' + $Spec.mongo.version)) {
      throw 'MongoDB cannot start. Install Microsoft Visual C++ v14 x64 Redistributable from https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist then retry. Administrator approval may be needed for that Microsoft installer.'
    }
    $Shell = New-Object -ComObject WScript.Shell
    $Desktop = [Environment]::GetFolderPath('Desktop')
    foreach ($Entry in @(@('Booking - Start','start'),@('Booking - Stop','stop'),@('Booking - Backup','backup'),@('Booking - Restore','restore'),@('Booking - LAN Addresses','addresses'))) {
      $Shortcut = $Shell.CreateShortcut((Join-Path $Desktop ($Entry[0] + '.lnk')))
      $Shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
      $Shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $App 'windows\menu.ps1') + '" -Action ' + $Entry[1]
      $Shortcut.WorkingDirectory = $App
      $Shortcut.Save()
    }
    Tell 'Installed. Double-click Booking - Start on your desktop. No command line is needed. Installation has not started the application.'
    return
  }
  if ($Action -eq 'start') {
    if (!(Test-Path $Node) -or !(Test-Path $Controller)) { throw 'Run Install.cmd first.' }
    $StateFile = Join-Path $Root 'state.json'
    if (Test-Path (Join-Path $Root 'operation.lock')) {
      $Existing = if (Test-Path $StateFile) { Get-Content $StateFile -Raw | ConvertFrom-Json } else { $null }
      $Lock = Get-Content (Join-Path $Root 'operation.lock') -Raw | ConvertFrom-Json
      $Alive = Get-Process -Id $Lock.pid -ErrorAction SilentlyContinue
      if ($Alive) {
        if ($Existing -and $Existing.instance -eq $Lock.instance -and $Existing.phase -eq 'running') { Start-Process 'http://127.0.0.1:17880'; Tell ($Existing.addresses -join "`n"); return }
        throw 'The application is starting, stopping or maintenance is in progress. Try again shortly.'
      }
    }
    $LaunchId = [guid]::NewGuid().ToString()
    $OutputLog = Join-Path $Root ('logs\launcher-' + $LaunchId + '.log')
    $ErrorLog = Join-Path $Root ('logs\launcher-' + $LaunchId + '-error.log')
    $Process = Start-Process -FilePath $Node -ArgumentList ('"' + $Controller + '" run') -WindowStyle Hidden -PassThru -RedirectStandardOutput $OutputLog -RedirectStandardError $ErrorLog
    for ($i = 0; $i -lt 180; $i++) {
      Start-Sleep -Milliseconds 500
      $Process.Refresh()
      if (Test-Path $StateFile) {
        $State = Get-Content $StateFile -Raw | ConvertFrom-Json
        if ($State.pid -eq $Process.Id) {
          if ($State.phase -eq 'error') { throw $State.error }
          if ($State.phase -eq 'running') {
            if (!$NoGui) { Start-Process 'http://127.0.0.1:17880' }
            Tell ("Running. Keep this host awake and signed in.`n" + ($State.addresses -join "`n") + "`nFor LAN access, allow Node only on Private networks if Windows asks. Do not forward router ports. Data: " + $Root)
            return
          }
        }
      }
      if ($Process.HasExited) { throw ('Startup failed. See ' + $ErrorLog) }
    }
    throw 'Startup timed out. Inspect logs before trying again.'
  }
  if ($Action -eq 'stop') { [void](Invoke-Controller -Arguments @('stop')); Tell 'Stopped. Data remains in your local data directory.'; return }
  if ($Action -eq 'backup') {
    if (!(Confirm 'Backup stops the system for all LAN users. The system stays stopped afterward. Continue?')) { return }
    $Backup = Invoke-Controller -Arguments @('backup')
    Tell ("Backup verified: " + $Backup + "`nCopy the entire backup folder to another disk. Double-click Start to resume.")
    if (!$NoGui) { Start-Process explorer.exe -ArgumentList ('"' + $Backup + '"') }
    return
  }
  if ($Action -eq 'restore') {
    $Picker = New-Object System.Windows.Forms.OpenFileDialog
    $Picker.Title = 'Choose manifest.json inside a booking backup folder'
    $Picker.Filter = 'Backup manifest (manifest.json)|manifest.json'
    $Picker.InitialDirectory = Join-Path $Root 'backups'
    if ($Picker.ShowDialog() -ne 'OK') { return }
    $Backup = Split-Path $Picker.FileName -Parent
    if (!(Confirm ("Restore this backup?`n" + $Backup + "`nThis stops all users, validates a new data directory and switches to it. Current data remains preserved. The system stays stopped afterward."))) { return }
    $Restored = Invoke-Controller -Arguments @('restore', $Backup, '--confirmed')
    Tell ("Restore verified: " + $Restored + "`nPrevious data is preserved. Double-click Start and check your orders.")
    return
  }
  if ($Action -eq 'addresses') {
    $State = Get-Content (Join-Path $Root 'state.json') -Raw | ConvertFrom-Json
    Tell ("Last known state: " + $State.phase + "`n" + ($State.addresses -join "`n") + "`nAddresses work only while the host is running. If Wi-Fi changes, stop and start to refresh.")
  }
} catch {
  $Text = $_.Exception.Message
  if (Test-Path (Join-Path $Root 'logs')) { Add-Content (Join-Path $Root 'logs\menu-errors.log') ((Get-Date -Format o) + ' ' + $Text) }
  Tell $Text
  exit 1
}
