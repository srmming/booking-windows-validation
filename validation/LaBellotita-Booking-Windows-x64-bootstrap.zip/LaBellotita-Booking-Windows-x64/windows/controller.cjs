'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const net = require('node:net');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');
const { MongoClient } = require('../backend/node_modules/mongodb');
const { privateIPv4 } = require('../backend/app');
const { atomicJSON, readJSON, acquireLock, generation, inventory, validateSnapshot, copyTreeExclusive } = require('./storage.cjs');
const runtime = require('./runtime.json');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function settings() {
  const testing = process.env.BOOKING_TEST_MODE === '1';
  if (!testing && (process.platform !== 'win32' || process.arch !== 'x64')) throw new Error('This package requires Windows x64.');
  const root = testing ? process.env.BOOKING_TEST_ROOT : path.join(process.env.LOCALAPPDATA || '', 'LaBellotitaBooking');
  if (!root || !path.isAbsolute(root)) throw new Error('Local data directory unavailable.');
  const appPort = testing ? Number(process.env.BOOKING_TEST_APP_PORT || 17880) : 17880;
  const dbPort = testing ? Number(process.env.BOOKING_TEST_DB_PORT || 17881) : 17881;
  for (const p of [appPort, dbPort]) if (!Number.isInteger(p) || p < 1024 || p > 65535) throw new Error('Invalid local port.');
  if (appPort === dbPort) throw new Error('Application and database ports must differ.');
  const mongod = testing ? process.env.BOOKING_TEST_MONGOD : path.join(root, 'runtime', runtime.mongo.directory, 'bin', 'mongod.exe');
  if (!mongod || !fs.existsSync(mongod)) throw new Error('Database runtime is missing. Run Install.cmd first.');
  const check = spawnSync(mongod, ['--version'], { encoding: 'utf8', windowsHide: true });
  if (check.error || check.status !== 0 || !check.stdout.includes(`v${runtime.mongo.version}`)) throw new Error('Database runtime cannot run or has the wrong version. Check VC++ x64 runtime and logs.');
  fs.mkdirSync(path.join(root, 'logs'), { recursive: true });
  return { root, appPort, dbPort, mongod, uri: `mongodb://127.0.0.1:${dbPort}/labellotita_booking_local` };
}
async function assertPortFree(port, host = '127.0.0.1') {
  const server = net.createServer();
  await new Promise((resolve, reject) => {
    server.once('error', () => reject(new Error(`Port ${port} is occupied. Stop the other program or contact support; no process was terminated.`)));
    server.listen(port, host, resolve);
  });
  await new Promise(resolve => server.close(resolve));
}
function launch(executable, args, options = {}) {
  const child = spawn(executable, args, { windowsHide: true, ...options });
  child.failure = null;
  child.finished = false;
  child.done = new Promise(resolve => {
    child.once('error', error => { child.failure = error; if (!child.pid) { child.finished = true; resolve(-1); } });
    child.once('exit', code => { child.finished = true; resolve(code); });
  });
  return child;
}
async function awaitExit(child, timeout = 60000) {
  const timedOut = Symbol('timeout');
  let timer;
  const result = await Promise.race([child.done, new Promise(resolve => { timer = setTimeout(() => resolve(timedOut), timeout); })]);
  clearTimeout(timer);
  if (result === timedOut) throw new Error('Clean stop timed out. No backup or restore was performed. Ask support to inspect logs.');
  return result;
}
async function stopApplication(child) {
  if (!child.finished) child.send('stop');
  const code = await awaitExit(child);
  if (code !== 0) throw new Error('Application did not stop cleanly. No snapshot was accepted.');
  return code;
}
async function connect(config, child) {
  for (let i = 0; i < (config.readinessAttempts ?? 120); i++) {
    if (child.failure || child.finished) throw new Error('MongoDB failed to start. See database logs; data has been preserved.');
    const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 300, connectTimeoutMS: 300 });
    try { await client.connect(); return client; } catch (_) { await client.close(); await sleep(250); }
  }
  throw new Error('Database readiness timed out. See logs.');
}
async function startDatabase(config, dir) {
  await assertPortFree(config.dbPort);
  const out = fs.openSync(path.join(config.root, 'logs', 'database-console.log'), 'a');
  const child = launch(config.mongod, ['--dbpath', dir, '--bind_ip', '127.0.0.1', '--port', String(config.dbPort), '--logpath', path.join(config.root, 'logs', 'database.log'), '--logappend', '--setParameter', 'diagnosticDataCollectionEnabled=false'], { stdio: ['ignore', out, out] });
  fs.closeSync(out);
  try {
    const client = await connect(config, child);
    const opts = await client.db('admin').command({ getCmdLineOpts: 1 });
    if (path.resolve(opts.parsed.storage.dbPath) !== path.resolve(dir)) { await client.close(); throw new Error('Database ownership verification failed.'); }
    return { child, client };
  } catch (error) {
    try { if (config.onPendingCleanup) config.onPendingCleanup(error, child); } catch (_) {}
    // Keep the caller's operation lock and child handle until this child is gone.
    // Windows SIGTERM would force-kill Mongo. Instead wait for our database to accept
    // an ownership-verified admin shutdown. No live child is abandoned on timeout.
    while (!child.finished) {
      const client = new MongoClient(config.uri, { serverSelectionTimeoutMS: 500, connectTimeoutMS: 500 });
      try {
        await client.connect();
        const opts = await client.db('admin').command({ getCmdLineOpts: 1 });
        if (path.resolve(opts.parsed.storage.dbPath) === path.resolve(dir)) {
          await stopDatabase({ child, client });
          break;
        }
      } catch (_) {} finally { await client.close(); }
      if (!child.finished) await Promise.race([child.done, sleep(1000)]);
    }
    throw error;
  }
}
async function stopDatabase(db, { indexWaitMS = 30000, indexRetryMS = 250 } = {}) {
  if (db.child.finished || db.child.failure) { await db.client.close(); throw new Error('Database exited unexpectedly; maintenance aborted.'); }
  const deadline = Date.now() + indexWaitMS;
  try {
    while (true) {
      try { await db.client.db('admin').command({ shutdown: 1, force: false, timeoutSecs: 30 }); break; }
      catch (error) {
        if (/MongoNetwork|MongoServerSelection/.test(error.name)) break;
        // Mongo8.0 returns code117 before shutdown if an index is building.
        // Wait for that specific operation to finish; never force or retry
        // unrelated permission, ownership or database errors.
        if (error.code !== 117 || !/^Index builds in progress while processing shutdown command/.test(error.message)) throw error;
        if (Date.now() >= deadline) throw new Error('Index builds did not finish within the safe shutdown window. Database remains owned; no snapshot was accepted.');
        if (db.onIndexWait) db.onIndexWait();
        await sleep(indexRetryMS);
      }
    }
  }
  finally { await db.client.close(); }
  const code = await awaitExit(db.child);
  if (code !== 0) throw new Error('Database did not stop cleanly. No snapshot was accepted.');
}
async function collectionCounts(client) {
  const db = client.db('labellotita_booking_local');
  const collections = await db.listCollections({}, { nameOnly: true }).toArray();
  const result = [];
  for (const c of collections.sort((a, b) => a.name.localeCompare(b.name))) result.push({ name: c.name, count: await db.collection(c.name).countDocuments({}) });
  return result;
}
async function coldDatabase(config, dir) {
  const db = await startDatabase(config, dir);
  try { return await collectionCounts(db.client); } finally { await stopDatabase(db); }
}
function addresses(port) {
  const values = new Set([`http://127.0.0.1:${port}`]);
  for (const items of Object.values(os.networkInterfaces())) for (const item of items || []) if (item.family === 'IPv4' && !item.internal && privateIPv4(item.address)) values.add(`http://${item.address}:${port}`);
  return [...values];
}
async function run(config) {
  const lock = acquireLock(config.root);
  let db, app, stopping = false, interval;
  const stateFile = path.join(config.root, 'state.json');
  const stopFile = path.join(config.root, 'stop.json');
  const journal = (event, detail) => {
    try { fs.appendFileSync(path.join(config.root, 'logs', 'lifecycle.log'), JSON.stringify({ at: new Date().toISOString(), pid: process.pid, instance: lock.instance, event, detail }) + os.EOL); } catch (_) {}
  };
  const status = (phase, error) => {
    journal('state-write', phase);
    try { atomicJSON(stateFile, { phase, error, pid: process.pid, instance: lock.instance, addresses: addresses(config.appPort) }); }
    catch (failure) { journal('state-write-failed', failure.message); throw failure; }
  };
  async function cleanup() {
    if (stopping) return;
    stopping = true;
    journal('cleanup-requested');
    clearInterval(interval);
    try {
      // Status metadata is auxiliary: a transient Windows file-sharing error
      // must not stop teardown after the polling interval has been cleared.
      try { status('stopping'); } catch (error) { journal('state-stop-warning', error.message); }
      let applicationFailure;
      if (app) {
        journal(app.finished ? 'http-already-exited' : 'http-stop-send', app.pid);
        try { journal('http-child-exited', await stopApplication(app)); }
        catch (error) { applicationFailure = error; journal('http-stop-failed', error.message); }
      }
      // Once HTTP has exited, cleanly stop our owned DB even if HTTP exited
      // nonzero. Preserve that failure so backups never accept this shutdown.
      if (db && (!app || app.finished)) { journal('mongo-stop-start', db.child.pid); db.onIndexWait = () => journal('mongo-waiting-index-builds'); await stopDatabase(db); journal('mongo-child-exited', db.child.exitCode); }
      if (applicationFailure) throw applicationFailure;
      status('stopped');
    } catch (error) { journal('cleanup-failed', error.message); status('error', error.message); throw error; }
    finally { if ((!app || app.finished) && (!db || db.child.finished)) { lock.release(); journal('lease-released'); } }
  }
  try {
    status('starting');
    await assertPortFree(config.appPort, '0.0.0.0');
    db = await startDatabase({ ...config, onPendingCleanup: error => status('error', `${error.message} Waiting to cleanly stop the owned database; the operation lock remains held.`) }, generation(config.root));
    const out = fs.openSync(path.join(config.root, 'logs', 'application.log'), 'a');
    const env = { ...process.env, NODE_ENV: 'production', APP_MODE: 'windows-lan', DEMO_MODE: 'false', MONGODB_URI: config.uri, PORT: String(config.appPort) };
    delete env.APP_USERNAME; delete env.APP_PASSWORD; delete env.REACT_APP_API_URL; delete env.NODE_OPTIONS; delete env.NODE_PATH;
    app = launch(process.execPath, [path.resolve(__dirname, '../backend/server.js')], { cwd: path.resolve(__dirname, '..'), env, stdio: ['ignore', out, out, 'ipc'] });
    fs.closeSync(out);
    let ready = false;
    for (let i = 0; i < 120; i++) {
      if (app.failure || app.finished || db.child.finished) throw new Error('Application failed to start. See logs.');
      try {
        const response = await fetch(`http://127.0.0.1:${config.appPort}/health`, { signal: AbortSignal.timeout(500) });
        const body = await response.json();
        if (response.ok && body.mode === 'business') { ready = true; break; }
      } catch (_) {}
      await sleep(250);
    }
    if (!ready) throw new Error('Application readiness timed out. See logs.');
    fs.writeFileSync(path.join(config.root, 'addresses.txt'), addresses(config.appPort).join(os.EOL));
    status('running');
    interval = setInterval(() => {
      if (fs.existsSync(stopFile)) {
        try {
          if (readJSON(stopFile).instance === lock.instance) {
            journal('stop-request-seen');
            fs.unlinkSync(stopFile);
            cleanup().catch(error => { journal('cleanup-rejected', error.message); console.error(error.message); process.exitCode = 1; });
          }
        } catch (error) { journal('stop-request-check-failed', error.message); }
      }
    }, 300);
    const unexpectedExit = () => {
      if (stopping) return;
      cleanup().then(() => status('error', 'A managed process exited unexpectedly. Data is preserved; inspect logs before restarting.')).catch(() => {});
      process.exitCode = 1;
    };
    app.done.then(unexpectedExit);
    db.child.done.then(unexpectedExit);
    for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => cleanup().catch(() => { process.exitCode = 1; }));
  } catch (error) {
    try { await cleanup(); } catch (_) {}
    status('error', error.message);
    throw error;
  }
}
async function stop(config) {
  const file = path.join(config.root, 'operation.lock');
  if (!fs.existsSync(file)) return;
  const owner = readJSON(file);
  try { process.kill(owner.pid, 0); } catch (e) { if (e.code === 'ESRCH') return; throw e; }
  const state = readJSON(path.join(config.root, 'state.json'));
  if (state.instance === owner.instance && state.phase === 'error') throw new Error(state.error || 'Startup cleanup is still in progress. Inspect logs.');
  if (state.instance !== owner.instance || !['running', 'starting', 'stopping'].includes(state.phase)) throw new Error('Another maintenance operation is active. Try later.');
  atomicJSON(path.join(config.root, 'stop.json'), { instance: owner.instance });
  for (let i = 0; i < 240; i++) {
    const current = readJSON(path.join(config.root, 'state.json'));
    if (current.instance === owner.instance && current.phase === 'error') throw new Error(current.error || 'Owned-process cleanup failed. Inspect logs; no forced termination was attempted.');
    if (!fs.existsSync(file) || readJSON(file).instance !== owner.instance) {
      const final = readJSON(path.join(config.root, 'state.json'));
      if (final.instance === owner.instance && final.phase === 'error') throw new Error(final.error);
      return;
    }
    await sleep(500);
  }
  throw new Error('Stop timed out. No forced termination was attempted. See logs.');
}
async function backup(config) {
  await stop(config);
  const lock = acquireLock(config.root);
  try {
    const dir = generation(config.root);
    const collections = await coldDatabase(config, dir);
    const id = `backup-${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomUUID()}`;
    const target = path.join(config.root, 'backups', id);
    fs.mkdirSync(target, { recursive: true });
    copyTreeExclusive(dir, path.join(target, 'db'));
    const files = await inventory(path.join(target, 'db'));
    atomicJSON(path.join(target, 'manifest.json'), { format: 'booking-cold-v1', mongoVersion: runtime.mongo.version, createdAt: new Date().toISOString(), collections, files });
    await validateSnapshot(target, runtime.mongo.version);
    return target;
  } finally { lock.release(); }
}
async function restore(config, source) {
  if (!source || !path.isAbsolute(source)) throw new Error('Choose a backup folder.');
  await stop(config);
  const lock = acquireLock(config.root);
  try {
    const manifest = await validateSnapshot(source, runtime.mongo.version);
    // Fresh generation; hashes are checked again on the copied files, avoiding source changes during copy.
    const name = `data-${crypto.randomUUID()}`;
    const staging = path.join(config.root, 'generations', name);
    fs.mkdirSync(path.dirname(staging), { recursive: true });
    copyTreeExclusive(path.join(source, 'db'), staging);
    const files = await inventory(staging);
    files.sort((a, b) => a.path.localeCompare(b.path));
    const expected = [...manifest.files].sort((a, b) => a.path.localeCompare(b.path));
    if (JSON.stringify(files) !== JSON.stringify(expected)) throw new Error('Copied backup verification failed.');
    const counts = await coldDatabase(config, staging);
    if (JSON.stringify(counts) !== JSON.stringify(manifest.collections)) throw new Error('Restored database counts do not match. Original data remains active.');
    const old = fs.existsSync(path.join(config.root, 'active.json')) ? readJSON(path.join(config.root, 'active.json')) : null;
    atomicJSON(path.join(config.root, `restore-receipt-${crypto.randomUUID()}.json`), { previous: old, restored: name, source, verifiedAt: new Date().toISOString(), counts });
    atomicJSON(path.join(config.root, 'active.json'), { generation: name });
    return staging;
  } finally { lock.release(); }
}
async function main() {
  const config = settings();
  const command = process.argv[2];
  if (command === 'run') return run(config);
  if (command === 'stop') return stop(config);
  if (command === 'backup') return console.log(await backup(config));
  if (command === 'restore' && process.argv[4] === '--confirmed') return console.log(await restore(config, process.argv[3]));
  throw new Error('Unknown command or restore confirmation missing.');
}
if (require.main === module) main().catch(error => { console.error(error.message); process.exitCode = 1; });
module.exports = { settings, assertPortFree, addresses, backup, restore, stop, startDatabase, stopDatabase, coldDatabase, launch, awaitExit, stopApplication };
